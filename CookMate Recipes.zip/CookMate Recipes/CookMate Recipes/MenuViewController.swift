//
//  MenuViewController.swift
//  CookMate Recipes
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit

class MenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           return tableData.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           //return the cell with data.
           //Create cells dynamically
           var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "item", for: indexPath)
           //Assign the data to the cell.
           cell.textLabel?.text = tableData[indexPath.row].name
           //return cell
           return cell
       }

    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    var tableData: [Recipe] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          let transition = segue.identifier
          if transition == "itemViewSegue"{
              let destination = segue.destination as! DescriptionViewController
              destination.item = tableData[(tableViewOutlet.indexPathForSelectedRow?.row)!]
          }
      }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
