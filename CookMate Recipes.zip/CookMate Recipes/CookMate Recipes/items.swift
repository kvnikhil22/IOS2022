//
//  Movie.swift
//  CookMate Recipes
//
//  Created by Krishnan Venkatesh,Nikhil on 5/4/22.
//

import Foundation
import UIKit
struct items{

    let image:UIImage
    
}
let itemArray : [items] = [
    items(image:UIImage(named: "biryani")!),
    items(image:UIImage(named: "butterchicken")!),
    items(image:UIImage(named: "curdrice")!),
    items(image:UIImage(named: "jeerarice")!),
    items(image:UIImage(named: "kadaipaneer")!),
    items(image:UIImage(named: "palakpaneer")!),
    
]
