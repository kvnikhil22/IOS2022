//
//  DescriptionViewController.swift
//  CookMate Recipes
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit

class DescriptionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        itemName.text = item?.name
        descriptionOutelt.text = item?.description
        imageOutlet.image = UIImage(named: item?.imagePath ?? "")
        var list = " "
        for item in item?.ingrediants ?? []{
            list = list + item + "\n"
            
        }
        ingredentList.text = list 
        
        // Do any additional setup after loading the view.
    }
    
    var item: Recipe? = nil
    

    @IBOutlet weak var imageOutlet: UIImageView!
    
    
    @IBOutlet weak var descriptionOutelt: UITextView!
    
    @IBOutlet weak var ingredentList: UILabel!
    @IBOutlet weak var itemName: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
