//
//  NotFoundViewController.swift
//  CookMate Recipes
//
//  Created by Krishnan Venkatesh,Nikhil on 5/4/22.
//

import UIKit

class NotFoundViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        notFoundPage.image = UIImage(named: "nopagefound")
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var notFoundPage: UIImageView!
    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
