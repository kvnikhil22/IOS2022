//
//  AddRecipeViewController.swift
//  CookMate Recipes
//
//  Created by Konduri,Sai Deep on 4/6/22.
//

import UIKit
import Foundation

struct HelpResponse: Codable {
    let _id: String
    let name, contact, description : String?
   
}

class AddRecipeViewController: UIViewController {

    @IBOutlet weak var name: UITextField!
    
    
    @IBOutlet weak var number: UITextField!
    
    
    @IBOutlet weak var desc: UITextView!
    
    @IBAction func submit(_ sender: UIButton) {
        postData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func postData() {
           
            // 1) create URL
            guard let url = URL(string:"https://iosserve.herokuapp.com/help") else { fatalError("error with URL ")}
            // 2) create request
            var httpRequest = URLRequest(url: url)
            httpRequest.httpMethod = "POST"
            let n = name.text!
            let m = number.text!
            let des = desc.text!
        let parameters: [String: Any] = ["name": n, "contact": m, "description": des]
           
            httpRequest.httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])
           
            // 3) create data task with closures
            let dataTask = URLSession.shared.dataTask(with: httpRequest) {( data, response, Error) in
                
                // 3.1) null check
                guard let data = data else {return }
             
                // 3.2) parsing the JSON to struct
                
                do {
                    let decoded = try JSONDecoder().decode(HelpResponse.self, from: data);
                    
                    print(decoded)
                    DispatchQueue.main.async {
                      
                        
                    }
                   
                } catch let error {
                    print("Error in JSON parsing", error)
                    
                }
            }
            // 4) make an API call
            dataTask.resume()
        }
        
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
