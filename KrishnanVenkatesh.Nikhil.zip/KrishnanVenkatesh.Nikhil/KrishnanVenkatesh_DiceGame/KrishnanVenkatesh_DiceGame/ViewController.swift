//
//  ViewController.swift
//  KrishnanVenkatesh_DiceGame
//
//  Created by Krishnan Venkatesh,Nikhil on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var playerOne: UITextField!
    @IBOutlet weak var playerTwo: UITextField!
    @IBOutlet weak var displayScorep1: UILabel!
    @IBOutlet weak var displayScorep2: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    @IBAction func submitButton(_ sender: UIButton) {
        displayScorep1.text! = ""
        displayScorep2.text! = ""
        displayFinal.text! = ""
        let firstName = playerOne.text
        let secondName = playerTwo.text
        
        let c1 : Int = createRandom()
        let c2 : Int = createRandom()
        
        displayScorep1.text = "\(firstName) roll is \(c1)"
        displayScorep2.text = "\(secondName) roll is \(c2)"
        
        if(c1>c2){
            displayFinal.text = "\(firstName) won the game"
            
        }
        else if(c1<c2){
            displayFinal.text = "\(secondName) won the game"
        }
        else{
            displayFinal.text = "The game is tie"
        }

        
        
    }
    
    @IBOutlet weak var displayFinal: UILabel!
}
func createRandom() -> Int {
    return Int.random(in:0..<6)
}


